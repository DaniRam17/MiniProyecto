#ifndef GESTIONACCESOSVIEW_H
#define GESTIONACCESOSVIEW_H

#include <SFML/Graphics.hpp>
#include "HashTable.h"


void mostrarVistaGestionAccesos(sf::Font& fuente, HashTable& tabla);

#endif
