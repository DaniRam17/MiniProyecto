#ifndef GESTIONACCESOSVIEW_H
#define GESTIONACCESOSVIEW_H

#include <SFML/Graphics.hpp>
#include "HashTable.h"

// ✅ Función principal de interfaz de gestión de accesos
void mostrarVistaGestionAccesos(sf::Font& fuente, HashTable& tabla);

#endif
