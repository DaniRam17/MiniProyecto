#ifndef PACIENTESVIEW_H
#define PACIENTESVIEW_H

#include <SFML/Graphics.hpp>

void mostrarVistaPacientes(sf::Font& fuente);

#endif
